import React from "react";
import "./index.css";


const Spinner = () => {
	return (
		<div className="lds-dual-ring"></div>
	);
};

export default Spinner;
